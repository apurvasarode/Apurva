# Top-Songs-Analysis

## Problem Statement

> Every year Billboard releases the list of top tracks. The judging is based on the amount of times the song was played on media platforms, The sales it made, its popularity among the people and its review by critics. <br>

> As time passes by the defination of a hit single changes. In the 1960s it was the smooth jazzy sound of Frank Sinatra and in late 2016 it was the high pitched vocals of Justin Beiber.<br>

> A few questions arise, <br> 
**Is there common factor that make these songs a hit? and if so What are these factors? <br>
  How do our preferences change as time goes by? <br>
  Can we analyze the data to understand why songs go to the top of the charts?** <br>

> Answering these questions might help our target audiences namely music artists and record labels. 

